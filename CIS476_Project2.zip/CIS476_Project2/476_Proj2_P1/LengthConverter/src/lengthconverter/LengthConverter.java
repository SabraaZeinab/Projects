package lengthconverter;
        
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LengthConverter extends JFrame {
    private JTextField txtInput, txtResult;
    private JLabel lblKilometer;
    private JComboBox<String> cmbUnits;
    private JButton btnConvert;

    public LengthConverter() {
        txtInput = new JTextField(15);
        txtResult = new JTextField(15);
        txtResult.setEditable(false);
        lblKilometer = new JLabel("Kilometer");
        cmbUnits = new JComboBox<>();
        cmbUnits.addItem("Mile");
        cmbUnits.addItem("Yard");
        cmbUnits.addItem("Foot");
        btnConvert = new JButton("Convert");

        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.CENTER));

        panel1.add(txtInput);
        panel1.add(lblKilometer);
        panel2.add(txtResult);
        panel2.add(cmbUnits);
        panel3.add(btnConvert);

        setLayout(new BorderLayout());
        setSize(new Dimension(500, 300));
        setTitle("Length Converter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        getContentPane().add(panel1, BorderLayout.NORTH);
        getContentPane().add(panel2, BorderLayout.CENTER);
        getContentPane().add(panel3, BorderLayout.SOUTH);

        btnConvert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double kilometer = Double.parseDouble(txtInput.getText());
                    if (cmbUnits.getSelectedIndex() == 0) {
                        double mile = 0.621371 * kilometer;
                        txtResult.setText(mile + "");
                    }
                    if (cmbUnits.getSelectedIndex() == 1) {
                        double yard = 1093.6132 * kilometer;
                        txtResult.setText(yard + "");
                    }
                    if (cmbUnits.getSelectedIndex() == 2) {
                        double feet = 3280.84 * kilometer;
                        txtResult.setText(feet + "");

                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LengthConverter :: new);
        
            }
        
}