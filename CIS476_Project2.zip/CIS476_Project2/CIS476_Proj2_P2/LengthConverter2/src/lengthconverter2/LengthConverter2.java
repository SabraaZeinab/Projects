package lengthconverter2;
        
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LengthConverter2 extends JFrame {
    private JTextField txtInput, txtResult;
    private JLabel lblKilometer;
    private JComboBox<String> cmbUnits;
    private JButton btnConvert;
    double result;
    String cmbunit;

    public LengthConverter2() {
        txtInput = new JTextField(15);
        txtResult = new JTextField(15);
        txtResult.setEditable(false);
        lblKilometer = new JLabel("Kilometer");
        cmbUnits = new JComboBox<>();
        cmbUnits.addItem("Mile");
        cmbUnits.addItem("Yard");
        cmbUnits.addItem("Foot");
        btnConvert = new JButton("Convert");

        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.CENTER));

        panel1.add(txtInput);
        panel1.add(lblKilometer);
        panel2.add(txtResult);
        panel2.add(cmbUnits);
        panel3.add(btnConvert);

        setLayout(new BorderLayout());
        setSize(new Dimension(500, 300));
        setTitle("Length Converter2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        getContentPane().add(panel1, BorderLayout.NORTH);
        getContentPane().add(panel2, BorderLayout.CENTER);
        getContentPane().add(panel3, BorderLayout.SOUTH);

        btnConvert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double kilometer = Double.parseDouble(txtInput.getText());
                    if (cmbUnits.getSelectedIndex() == 0) {
                        result = 0.621371 * kilometer;
                        cmbunit = " Mile";
                    }
                    if (cmbUnits.getSelectedIndex() == 1) {
                        result = 1093.6132 * kilometer;
                        cmbunit = " Yard";
                    }
                    if (cmbUnits.getSelectedIndex() == 2) {
                        result = 3280.84 * kilometer;
                        cmbunit = " Feet";
                    }
        // get output in string from result
        // round result to 2 decimal points
             String decimals = String.format("%.2f", result);
             System.out.println (decimals );
        // convert in exp. notation
            String output = String.format("%6.4e", Double.parseDouble(decimals));
        // add units to converted amount
            output = output + cmbunit;
        // set output field
            txtResult.setText(output);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
         SwingUtilities.invokeLater(LengthConverter2 :: new);
         }
}