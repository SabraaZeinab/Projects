package project1;

    import java.io.File;
    import java.io.FileNotFoundException;
    import java.util.ArrayList;
    import java.util.Scanner;
    


public class RegularPolygonMain {
    
    
    public static void main(String[] args) {
        
     ArrayList<RegularPolygon>polygon=new ArrayList<>();
     
         
    try
    {
        Scanner file = new Scanner(new File("/Users/zeinabsabra/NetBeansProjects/Project1/Input.txt"));
     
         while(file.hasNext())
         {
             
             String line=file.nextLine();
            
             String[] tokens = line.split(" ");
             
             if(tokens.length == 2)
                 polygon.add(new RegularPolygon(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1])));
             
             
             
             else if(tokens.length == 4)
                polygon.add(new RegularPolygon(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3]) ));              
         }
         for(RegularPolygon r:polygon)
             System.out.println(r.toString());
     }
    catch(FileNotFoundException e)
    {
        e.printStackTrace();
    }
    }
    
}
