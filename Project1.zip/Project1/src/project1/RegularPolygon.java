package project1;


import java.text.DecimalFormat;



public class RegularPolygon {
    private int numSides;
    private double side;
    private double x;
    private double y;
    
    DecimalFormat df= new DecimalFormat("##.###");
    
    /**
     *
     */
    public RegularPolygon() {
        numSides = 3;
        side = 1.0;
        x = 0;
        y = 0;
        
    }

    public RegularPolygon(int numSides, double side) {
        this.numSides=numSides;
        this.side = side;
    }
    public RegularPolygon (int numSides, double side, double x, double y)
    {
        this.numSides = numSides;
        this.side = side; 
        this.x=x;
        this.y=y;
    }
    

    public int getNumSides() {
        return numSides;
    }

    public void setNumSides(int numSides) {
        this.numSides = numSides;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    public double getPerimeter(){
        return numSides*side;
        
    }
    public double getArea(){
        return (numSides*side*side)/(4*Math.tan(Math.PI/numSides));
    }
    @Override
    public String toString(){
        return numSides + "" +(int)side+ "("+(int)x + "," + (int)y +")"+ (int) getPerimeter()+""+ df.format(getArea());
        
    }
          
}
