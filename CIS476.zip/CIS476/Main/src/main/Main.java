
package main;

import java.io.*;
import java.io.FileNotFoundException;
import java.util.Scanner;

 class Client
{
    private final  AbstractScreen AbstractScreen;
    private final AbstractCamera AbstractCamera;
    private final AbstractGPU AbstractGPU;

    public Client(AbstractFactoryWidget factory)
    {
        AbstractCamera = factory.CreateCamera();
        AbstractScreen = factory.CreateScreen();
        AbstractGPU = factory.CreateGPU();

    }
    public void Run()
    {
        AbstractScreen.Display(AbstractScreen);
        AbstractCamera.Display(AbstractCamera);
        AbstractGPU.Display(AbstractGPU);
    }

}

 class ScreenIPhone11 extends AbstractScreen
{

    @Override
    public  void Display(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 11 " );
    }
}
 class CameraIPhone11 extends AbstractCamera
{

    @Override public  void Display(AbstractCamera a)
    {
        System.out.println(" Camera iPhone 11  " );
    }
}
 class GPUIPhone11 extends AbstractGPU
{
    @Override public void Display(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 11 " );
    }
}
 class ScreenIPhon12 extends AbstractScreen
{
    @Override public  void Display(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 12 " );
    }
}
 class GPUIPhone12 extends AbstractGPU
{

    @Override public  void Display(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 12 ");
    }
}

 class CameraIPhone12 extends AbstractCamera
{
    @Override public  void Display(AbstractCamera a)
    {
        System.out.println("  Camera iPhone 12 " );
    }
}
 class ScreenIPhon13 extends AbstractScreen
{
    @Override public  void Display(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 13 " );
    }
}
 class GPUIPhone13 extends AbstractGPU
{

    @Override public  void Display(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 13 " );
    }
}

 class CameraIPhone13 extends AbstractCamera
{
    @Override public  void Display(AbstractCamera a)
    {
        System.out.println("  Camera iPhone 13 " );
    }
}
 class ScreenIPhon14 extends AbstractScreen
{
    @Override public  void Display(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 14 " );
    }
}
 class GPUIPhone14 extends AbstractGPU
{

    @Override public  void Display(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 14 " );
    }
}

 class CameraIPhone14 extends AbstractCamera
{
    @Override public  void Display(AbstractCamera a)
    {
        System.out.println("  Camera iPhone 14  " );
    }
}
abstract class AbstractScreen
{
    public abstract void Display(AbstractScreen a);
}
abstract class AbstractGPU
{
    public abstract void Display(AbstractGPU a);
}

abstract class AbstractCamera
{
    public abstract void Display(AbstractCamera a);
}


 abstract class AbstractFactoryWidget
{

    public abstract AbstractScreen
    CreateScreen();
    public abstract AbstractCamera
    CreateCamera();
    public abstract AbstractGPU
    CreateGPU();
}

 class ConcreteIPhone11 extends AbstractFactoryWidget
{
    @Override public  AbstractScreen CreateScreen()
    {
        return new ScreenIPhone11();
    }
    @Override public  AbstractGPU CreateGPU()
    {
        return new GPUIPhone11();
    }
    @Override public  AbstractCamera CreateCamera()
    {
        return new CameraIPhone11();
    }
}
 class ConcreteIPhone12 extends AbstractFactoryWidget
{
    @Override public  AbstractScreen CreateScreen()
    {
        return new ScreenIPhon12();
    }
    @Override public  AbstractGPU CreateGPU()
    {
        return new GPUIPhone12();
    }
    @Override public  AbstractCamera CreateCamera()
    {
        return new CameraIPhone12();
    }
}
 class ConcreteIPhone13 extends AbstractFactoryWidget
{
    @Override public  AbstractScreen CreateScreen()
    {
        return new ScreenIPhon13();
    }
    @Override public  AbstractGPU CreateGPU()
    {
        return new GPUIPhone13();
    }
    @Override public  AbstractCamera CreateCamera()
    {
        return new CameraIPhone13();
    }
}
 class ConcreteIPhone14 extends AbstractFactoryWidget
{
    @Override public  AbstractScreen CreateScreen()
    {
        return new ScreenIPhon14();
    }
    @Override public  AbstractGPU CreateGPU()
    {
        return new GPUIPhone14();
    }
    @Override public  AbstractCamera CreateCamera()
    {
        return new CameraIPhone14();
    }
}



public class Main {
    public static void main(String[] args) throws IOException, FileNotFoundException {
        AbstractFactoryWidget factoryIPhone11= new ConcreteIPhone11();
        Client c1= new Client(factoryIPhone11);
        AbstractFactoryWidget factoryIPhone12= new ConcreteIPhone12();
        Client c2= new Client(factoryIPhone12);
        AbstractFactoryWidget factoryIPhone13= new ConcreteIPhone13();
        Client c3= new Client(factoryIPhone13);
        AbstractFactoryWidget factoryIPhone14= new ConcreteIPhone14();
        Client c4= new Client(factoryIPhone14);

        System.out.println("Hello world!");
        int a=0,b=0,c=0,d=0;


        File file = new File("/Users/zeinabsabra/NetBeansProjects/Main/src/main/Input.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String phone;



        while ((phone = br.readLine()) != null){

            if(phone !=null){

                switch(phone){
                    case "iPhone 11" -> {
                        if(a>1)
                        {
                            System.out.println("IPhone 11 tested more than twice!...");
                        }
                        else
                        {
                            System.out.println(phone);

                            c1.Run();
                        }
                        a++;

                    }
                    case "iPhone 12" -> {
                        if(b>1)
                        {
                            System.out.println("IPhone 12 tested more than twice!...");
                        }
                        else
                        {
                            System.out.println(phone);



                            c2.Run();
                        }
                        b++;
                    }
                    case "iPhone 13" -> {
                        if(c>1)
                        {
                            System.out.println("IPhone 13 tested more than twice!...");
                        }
                       else
                        {
                            System.out.println(phone);



                            c3.Run();
                        }
                        c++;
                    }
                    case "iPhone 14" -> {
                        if(d>1)
                        {
                            System.out.println("IPhone 14 tested more than twice!...");
                        }
                        else
                        {
                            System.out.println(phone);



                            c4.Run();
                        }
                        d++;
                    }
                    default -> {
                    }
                }

            }
        }



    }

    }
