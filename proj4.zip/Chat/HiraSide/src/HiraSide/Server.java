
package chat;
 import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.scene.layout.VBox;
public class Server {
    private ServerSocket serversocket;
    private Socket socket;
    private BufferedReader bufferreader;
    private BufferedWriter bufferwriter;
    
    public Server(ServerSocket serversocket){
        try{
        this.serversocket=serversocket;
        this.socket=serversocket.accept();
        
        this.bufferreader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.bufferwriter=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        }
        catch(IOException e){
            System.out.println("Error creating Server!...");
            e.printStackTrace();
        }
    }
    
    public void sendMassageToClient(String massageToClient){
        try{
            bufferwriter.write(massageToClient);
            bufferwriter.newLine();
            bufferwriter.flush();
        }catch(IOException e){
            e.printStackTrace();
            System.out.println("Error sending Massage!...");
            closeEverything(socket, bufferreader, bufferwriter);
        }
    }
    
    public void recieveMassageFromClient(VBox vbox){
             new Thread(new Runnable(){
            @Override
            public void run(){
                while(socket.isConnected()){
                    try{
                        String messageFromClient=bufferreader.readLine();
                        HiraController.addLabel(messageFromClient,vbox);
                    }catch(IOException e){
                        e.printStackTrace();
                        System.out.println("Error Recieving Massage!...");
                        closeEverything(socket, bufferreader, bufferwriter);
                        break;
                    }
                    
                }
            }
        }).start();
        
    }
    public void closeEverything(Socket socket, BufferedReader bufferreader, BufferedWriter bufferwriter){
        try{
            if(bufferreader!=null){
                bufferreader.close();
            }
            if(bufferwriter!=null){
                bufferwriter.close();
            }
            if(socket!=null){
                socket.close();
            }
            
        }catch(IOException e){
            
        }
    }
}
