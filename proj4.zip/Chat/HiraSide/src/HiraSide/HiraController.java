
package chat;


//import java.awt.Insets;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public class HiraController implements Initializable {

   
    @FXML
    private Button sendButton;
    @FXML
    private TextField textfield;
    @FXML
    private ScrollPane scrollpane;
    @FXML
    private VBox vboxMassage;

    private Server server;
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        try{
            server=new Server(new ServerSocket(1234));
        }catch(IOException e){
            e.printStackTrace();
            System.out.println("Error Creating Server!...");
        }
        vboxMassage.heightProperty().addListener(new ChangeListener<Number>(){
            @Override
            public void changed(ObservableValue<? extends Number> observablle, Number oldValue, Number newValue){
                scrollpane.setVvalue((Double) newValue);
            }
        });
        
        server.recieveMassageFromClient(vboxMassage);
        
        sendButton.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                String massageToSend = textfield.getText();
                if(!massageToSend.isEmpty()){
                    HBox hbox=new HBox();
                    hbox.setAlignment(Pos.CENTER_RIGHT);
                    hbox.setPadding(new Insets(5, 5, 5, 10));
                    
                    Text text=new Text(massageToSend);
                    TextFlow textflow=new TextFlow(text);
                      
                    textflow.setStyle(  "-fx-beckground-color: PINK");
                    textflow.setPadding(new Insets(5, 10, 5, 10));
                    
                    hbox.getChildren().add(textflow);
                    vboxMassage.getChildren().add(hbox);
                    
                    server.sendMassageToClient(massageToSend);
                    textfield.clear();
                }
            }
        });
    }    
    
 static void addLabel(String massageFromClient, VBox vbox){
    HBox hbox= new HBox();
    hbox.setAlignment(Pos.CENTER_LEFT);
    hbox.setPadding(new Insets(5, 5, 5, 10));
    Text text=new Text(massageFromClient);
    TextFlow textflow = new TextFlow(text);
    textflow.setStyle("-fx-beckground-color: GREY");
    textflow.setPadding(new Insets(5, 10, 5, 10));
    hbox.getChildren().add(textflow);
    
    Platform.runLater(new Runnable()
    {
    @Override
    public void run()
    {
        vbox.getChildren().add(hbox);
    }
    });
    
}
   
        }