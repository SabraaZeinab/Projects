
package chat;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class Chat extends Application
{
    
 

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage stage) throws Exception {
        Parent parent = FXMLLoader.load(getClass().getResource("chatroomHira.fxml"));
        Scene scene = new Scene(parent);
        stage.setTitle("Hello");
        Image logo;
        logo = new Image("images/logo.jpeg");
        stage.getIcons().add(logo);
        stage.setScene(scene);
        stage.show();}
    
}

