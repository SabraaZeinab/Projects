
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Scanner;

abstract class OrderTicket
{
    public Ticket Ticket;
    public Decorator Decorator;
    
    public double Quantity(double a)
    {
        return 0;
    }
    public double Cost()
    {
        return 0;
    }
    public String decorate() 
    {
        return "Ticket: ";
    }
    public String TypeTicket(String a)
    {
        return a;
    }
}
abstract class Ticket extends OrderTicket
{
    double cost=0;
    @Override
     public double Quantity(double a)
    {
        cost= a*cost;
        return a;
    }
     @Override
    public double Cost()
    {
            return cost;
    }
    public String TypeTicket(String a)
    {
        if(a=="Student")
        {
            cost=8.0;
             return " Ticket: Student, ";
             
        }
        else if(a=="Adult")
        {
            cost=10.0;
            return " Ticket: Adult, ";
             
             
        }
        else if(a=="Senior")
        {
            cost=8.0;
             return " Ticket: Senior, ";
        }
        else 
            return "Invalid!";
    }
}
abstract class Decorator extends OrderTicket {
 
    protected OrderTicket orderTicket;
    public Decorator(Ticket ticket)
    {
        this.orderTicket = orderTicket;
    }
}
class singleton 
{
    private static singleton obj ; 
    private singleton()
    {
        obj=null;
    }
   public static singleton get(Decorator gift) 
    { 
        if (obj == null) 
            obj = new singleton() {};
        return obj; 
    }  
}
abstract class gift extends Decorator 
{
    double cost=0.0;
   public gift(Ticket ticket) {
       
        super(ticket);
    }
    @Override
    public double Quantity(double a)
    {
        cost= a*cost;
        return a;
    }
    @Override
    public String decorate() 
    {
        return " gift, ";
    }
    @Override
    public double Cost() {
        return cost;
    }

}
abstract class popcorn extends Decorator {

     double cost=6.0;
    public popcorn(Ticket ticket) {
        super(ticket);
    }
    @Override
    public double Quantity(double a)
    {
        cost= a*cost;
        return a;
    }
    @Override
    public String decorate() {
        return " popcorn, ";
    }
    @Override
    public double Cost() {
        return cost;
    }
}
abstract class chips extends Decorator {

     double cost=4.0;

    public chips(Ticket ticket) {
        super(ticket);
    }
    @Override
    public double Quantity(double a)
    {
        cost= a*cost;
        return a;
    }
    @Override
    public String decorate() {
        return " chips, ";
    }
    @Override
    public double Cost() {
        return cost;
    }
}
abstract class drink extends Decorator 
{
    private Ticket ticket;
    public drink(Ticket ticket) {
        super(ticket);
    }
    
    // standard constructors
    @Override
    public String decorate() {
        return ticket.decorate();
    }
}
abstract class coke extends drink{

    double cost=2.0;

    public coke(Ticket ticket) {
        super(ticket);
    }
    @Override
    public double Quantity(double a)
    {
        cost= a*cost;
        return cost;
    }
    @Override
    public String decorate() {
        return " coke, ";
    }
    
    @Override
    public double Cost() {
        return cost;
    }
}
abstract class sprite extends drink
{
     double cost=2.0;

    public sprite(Ticket ticket) {
        super(ticket);
    }
    @Override
    public double Quantity(double a)
    {
        cost= a*cost;
        return a;
    }
    @Override
    public String decorate() {
        return " sprite, ";
    }
    
    @Override
    public double Cost() {
        return cost;
    }
}

public class Theator {
    public static void main(String[] args) throws FileNotFoundException
    {
        DecimalFormat d= new DecimalFormat(".###");
        String s;
        double q;
        String result="";
        String partOrder;
        double totalCost=0;
        Scanner input = new Scanner(new File("D:\\courses\\CIS_476\\theator\\src\\main\\java\\order"));
     
         while(input.hasNext())
         {
            q=input.nextDouble();
            s=input.next();
            OrderTicket o1;
            if(null!=s)
            switch (s) {
                case "Adult" -> {
                    o1= new Ticket() {};
                    partOrder=(o1.Quantity(q)+o1.TypeTicket("Adult")+ "$" + o1.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=o1.Cost();
                }
                case "Student" -> {
                    o1 = new Ticket() {};
                    partOrder=(o1.Quantity(q)+o1.TypeTicket("Student")+ "$" + o1.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=o1.Cost();
                }
                case "Senior" -> {
                    o1 = new Ticket() {};
                    partOrder=(o1.Quantity(q)+o1.TypeTicket("Senior")+ "$" + o1.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=o1.Cost();
                }
                case "popcorn" -> {
                    Decorator popcorn= new popcorn(new Ticket() {}) {};
                    partOrder=(popcorn.Quantity(q)+popcorn.decorate()+ "$" + d.format(popcorn.Cost()));
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=popcorn.Cost();
                }
                case "chips" -> {
                    Decorator chips= new chips(new Ticket() {}) {};
                    partOrder=(chips.Quantity(q)+chips.decorate()+ "$" + d.format(chips.Cost()));
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=chips.Cost();
                }
                case "coke" -> {
                    Decorator coke= new coke(new Ticket() {}) {};
                    partOrder=(coke.Quantity(q)+coke.decorate()+ "$" + coke.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=coke.Cost();
                }
                case "sprite" -> {
                    Decorator sprite= new sprite(new Ticket() {}) {};
                    partOrder=(sprite.Quantity(q)+sprite.decorate()+ "$" + sprite.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=sprite.Cost();
                }
                case "gift" -> {
                    Decorator gift= new gift(new Ticket() {}) {};
                    singleton x=singleton.get(gift);
                    partOrder=(gift.Quantity(q)+gift.decorate()+ "$" + gift.Cost());
                    result=result +partOrder+ ", ";
                    System.out.println(partOrder);
                    totalCost+=gift.Cost();
                }
                default -> {
                }
            }
         }
     System.out.println("final order: "+result);
     System.out.println("total cost: "+d.format(totalCost));
    }
}