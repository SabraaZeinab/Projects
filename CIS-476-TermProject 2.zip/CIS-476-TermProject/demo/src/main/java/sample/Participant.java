package sample;
//dummy class for testing
public class Participant {

    private String screenName;

    public Participant() {}

    public Participant(String screenName) {
        this.screenName = screenName;
    }

    public String getScreenName() {
        return screenName;
    }

    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }
}
