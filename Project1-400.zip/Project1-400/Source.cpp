#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;
bool IsInSyllableList(string syllable)
{
	string SyllableList[] = { "ba", "da", "bab","dab", "bad", "dad", "aba", "ada", "ab", "ad" };
	string* p = find(SyllableList, SyllableList + 10, syllable);

	return (p != SyllableList + 10);
}




bool wordTester(string word)
{
	if (word.length() == 0)
		return true;

	if (word.length() == 1)
		return false;

	if (word.length() == 2 && !IsInSyllableList(word))
		return false;

	if (IsInSyllableList(word.substr(0, 2)) && IsInSyllableList(word.substr(0, 3)))
		return wordTester(word.substr(2)) || wordTester(word.substr(3));

	if (IsInSyllableList(word.substr(0, 2)))
		return wordTester(word.substr(2));

	if (IsInSyllableList(word.substr(0, 3)))
		return wordTester(word.substr(3));

	return false;


}

void testHelper(string s)
{
	string delimiter = " ";
	string sCopy = s;
	size_t pos = 0;
	string token;
	cout << "Input is: " << s << endl;
	cout << "output is: " << s;
	bool isCorrect = true;
	while ((pos = s.find(delimiter)) != string::npos) {
		token = s.substr(0, pos);
		isCorrect = isCorrect && wordTester(token);
		s.erase(0, pos + delimiter.length());
	}
	token = s;
	isCorrect = isCorrect && wordTester(token);
	s.erase(0, pos + delimiter.length());
	s = sCopy;
	if (isCorrect == true)
	{
		cout << "\tFound Out James Secrets" << endl;
	}
	if (isCorrect == false)
		cout << "\tImpersonator Caught"<< endl;

	while ((pos = s.find(delimiter)) != string::npos) {
		token = s.substr(0, pos);
		cout << token;

		if (wordTester(token))
		{
			cout << "\tword" << endl;
		}
		else 
		{
			cout << "\tnot word" << endl;
		}
		s.erase(0, pos + delimiter.length());
	}

	if (s.length() != 0)
	{
		token = s;
		cout << token;

		if (wordTester(token))
		{
			cout << "\tword" << endl;
		}
		else
		{
			cout << "\tnot word" << endl;
		}
		s.erase(0, pos + delimiter.length());
	}
	cout << "\n";
}

int main() {
	ifstream infile("CIS400A2.txt");
	string line;
	while (getline(infile, line))
	{
		testHelper(line);
	}
	return 0;
}

